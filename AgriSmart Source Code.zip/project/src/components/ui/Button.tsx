import React from 'react';

interface ButtonProps {
  children: React.ReactNode;
  href?: string;
  onClick?: () => void;
  variant?: 'primary' | 'secondary';
}

const Button = ({ children, href, onClick, variant = 'primary' }: ButtonProps) => {
  const baseClasses = "w-full flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md md:py-4 md:text-lg md:px-10";
  const variantClasses = {
    primary: "text-white bg-green-600 hover:bg-green-700",
    secondary: "text-green-600 bg-white hover:bg-green-50 border-green-600"
  };

  const className = `${baseClasses} ${variantClasses[variant]}`;

  if (href) {
    return (
      <div className="rounded-md shadow">
        <a href={href} className={className}>
          {children}
        </a>
      </div>
    );
  }

  return (
    <div className="rounded-md shadow">
      <button onClick={onClick} className={className}>
        {children}
      </button>
    </div>
  );
};

export default Button;