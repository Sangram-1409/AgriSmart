import React from 'react';
import { Cloud, Leaf, AlertTriangle, ShoppingBag, Trophy, Info } from 'lucide-react';
import FeatureCard from './ui/FeatureCard';
import SectionTitle from './ui/SectionTitle';

const Features = () => {
  const features = [
    {
      icon: <Leaf className="h-6 w-6" />,
      title: 'Crop Advisory',
      description: 'Expert guidance on crop management, disease prevention, and best practices.',
      image: 'https://images.unsplash.com/photo-1574943320219-553eb213f72d?auto=format&fit=crop&w=500&q=60'
    },
    {
      icon: <AlertTriangle className="h-6 w-6" />,
      title: 'Pest Alerts',
      description: 'Real-time alerts about pest outbreaks and control measures.',
      image: 'https://images.unsplash.com/photo-1530836369250-ef72a3f5cda8?auto=format&fit=crop&w=500&q=60'
    },
    {
      icon: <Cloud className="h-6 w-6" />,
      title: 'Weather Updates',
      description: 'Accurate weather forecasts and agricultural weather advisories.',
      image: 'https://images.unsplash.com/photo-1592982537447-6f2a6e0a3023?auto=format&fit=crop&w=500&q=60'
    },
    {
      icon: <ShoppingBag className="h-6 w-6" />,
      title: 'Marketplace',
      description: 'Connect with buyers and sellers for agricultural products.',
      image: 'https://images.unsplash.com/photo-1595665593673-bf1ad72905c0?auto=format&fit=crop&w=500&q=60'
    },
    {
      icon: <Trophy className="h-6 w-6" />,
      title: 'Success Stories',
      description: 'Learn from successful farmers and their innovative practices.',
      image: 'https://images.unsplash.com/photo-1589923188900-85dae523342b?auto=format&fit=crop&w=500&q=60'
    },
    {
      icon: <Info className="h-6 w-6" />,
      title: 'Sustainable Farming',
      description: 'Information about organic farming and sustainable practices.',
      image: 'https://images.unsplash.com/photo-1625246333195-78d9c38ad449?auto=format&fit=crop&w=500&q=60'
    }
  ];

  return (
    <div className="py-12 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionTitle
          title="Complete Farming Solutions"
          subtitle="Everything you need to make informed agricultural decisions"
        />

        <div className="mt-10">
          <div className="grid grid-cols-1 gap-10 sm:grid-cols-2 lg:grid-cols-3">
            {features.map((feature, index) => (
              <FeatureCard
                key={index}
                icon={feature.icon}
                title={feature.title}
                description={feature.description}
                image={feature.image}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Features;