import React, { useState } from 'react';
import SectionTitle from '../ui/SectionTitle';
import Button from '../ui/Button';

const CropRecommendation = () => {
  const [soilType, setSoilType] = useState('');
  const [season, setSeason] = useState('');
  const [showRecommendation, setShowRecommendation] = useState(false);

  const recommendations = {
    'clay-kharif': ['Rice', 'Cotton', 'Sugarcane'],
    'clay-rabi': ['Wheat', 'Chickpea', 'Mustard'],
    'loam-kharif': ['Maize', 'Soybean', 'Groundnut'],
    'loam-rabi': ['Potato', 'Onion', 'Tomato'],
    'sandy-kharif': ['Millet', 'Sesame', 'Pulses'],
    'sandy-rabi': ['Barley', 'Sunflower', 'Peas']
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setShowRecommendation(true);
  };

  const getRecommendedCrops = () => {
    const key = `${soilType}-${season}` as keyof typeof recommendations;
    return recommendations[key] || [];
  };

  return (
    <section className="py-12 bg-white" id="advisory">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionTitle 
          title="Crop Recommendation" 
          subtitle="Get personalized crop suggestions based on your conditions" 
        />
        
        <div className="mt-10 max-w-md mx-auto bg-gray-50 p-6 rounded-lg shadow-lg">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Soil Type
              </label>
              <select
                value={soilType}
                onChange={(e) => setSoilType(e.target.value)}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
                required
              >
                <option value="">Select soil type</option>
                <option value="clay">Clay Soil</option>
                <option value="loam">Loamy Soil</option>
                <option value="sandy">Sandy Soil</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">
                Season
              </label>
              <select
                value={season}
                onChange={(e) => setSeason(e.target.value)}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
                required
              >
                <option value="">Select season</option>
                <option value="kharif">Kharif (Monsoon)</option>
                <option value="rabi">Rabi (Winter)</option>
              </select>
            </div>

            <Button variant="primary" onClick={handleSubmit}>
              Get Recommendations
            </Button>
          </form>

          {showRecommendation && (
            <div className="mt-6 p-4 bg-white rounded-lg border border-green-200">
              <h3 className="text-lg font-medium text-gray-900">Recommended Crops:</h3>
              <ul className="mt-2 space-y-2">
                {getRecommendedCrops().map((crop, index) => (
                  <li key={index} className="flex items-center text-gray-700">
                    <span className="h-2 w-2 bg-green-500 rounded-full mr-2"></span>
                    {crop}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

export default CropRecommendation;