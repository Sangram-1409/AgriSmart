import React, { useState } from 'react';
import SectionTitle from '../ui/SectionTitle';
import ProductCard from './ProductCard';
import { Search } from 'lucide-react';

const MarketplaceSection = () => {
  const [searchTerm, setSearchTerm] = useState('');
  
  const products = [
    {
      name: 'Organic Fertilizer',
      price: 499,
      image: 'https://images.unsplash.com/photo-1585314062340-f1a5a7c9328d?auto=format&fit=crop&w=800&q=80',
      seller: 'Green Earth Co.',
      rating: 4
    },
    {
      name: 'Premium Seeds Pack',
      price: 299,
      image: 'https://images.unsplash.com/photo-1574943320219-553eb213f72d?auto=format&fit=crop&w=800&q=80',
      seller: 'Agro Seeds Ltd.',
      rating: 5
    },
    {
      name: 'Smart Irrigation System',
      price: 2999,
      image: 'https://images.unsplash.com/photo-1563514227147-6d2ff665a6a0?auto=format&fit=crop&w=800&q=80',
      seller: 'TechFarm Solutions',
      rating: 4
    },
    {
      name: 'Organic Pesticides',
      price: 799,
      image: 'https://images.unsplash.com/photo-1589923188900-85dae523342b?auto=format&fit=crop&w=800&q=80',
      seller: 'Eco Sprays Inc.',
      rating: 3
    }
  ];

  const filteredProducts = products.filter(product =>
    product.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <section className="py-12 bg-gray-50" id="marketplace">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionTitle 
          title="Marketplace" 
          subtitle="Find the best agricultural products and equipment" 
        />
        
        <div className="mt-8 relative">
          <div className="relative">
            <input
              type="text"
              placeholder="Search products..."
              className="w-full px-4 py-3 pl-12 rounded-lg border border-gray-300 focus:ring-2 focus:ring-green-500 focus:border-transparent"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <Search className="absolute left-4 top-3.5 h-5 w-5 text-gray-400" />
          </div>
        </div>

        <div className="mt-8 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {filteredProducts.map((product, index) => (
            <ProductCard key={index} {...product} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default MarketplaceSection;