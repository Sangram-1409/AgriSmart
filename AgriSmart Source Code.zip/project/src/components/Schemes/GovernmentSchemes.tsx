import React, { useState } from 'react';
import { Search, ExternalLink } from 'lucide-react';
import SectionTitle from '../ui/SectionTitle';

const GovernmentSchemes = () => {
  const [searchTerm, setSearchTerm] = useState('');

  const schemes = [
    {
      title: "PM-KISAN",
      description: "Direct income support of ₹6,000 per year to farmer families",
      eligibility: "All land-holding farmers' families",
      link: "https://pmkisan.gov.in/"
    },
    {
      title: "Pradhan Mantri Fasal Bima Yojana",
      description: "Crop insurance scheme to protect against crop failure",
      eligibility: "All farmers growing notified crops",
      link: "https://pmfby.gov.in/"
    },
    {
      title: "Kisan Credit Card",
      description: "Easy access to credit for farmers",
      eligibility: "All farmers, including small and marginal",
      link: "https://www.india.gov.in/spotlight/kisan-credit-card-kcc"
    },
    {
      title: "PM Krishi Sinchai Yojana",
      description: "Enhancing water efficiency through 'Per Drop More Crop'",
      eligibility: "All farmers seeking irrigation assistance",
      link: "https://pmksy.gov.in/"
    },
    {
      title: "National Agriculture Market (eNAM)",
      description: "Online trading platform for agricultural commodities",
      eligibility: "All farmers can sell through eNAM",
      link: "https://enam.gov.in/"
    }
  ];

  const filteredSchemes = schemes.filter(scheme =>
    scheme.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    scheme.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <section className="py-12 bg-white" id="schemes">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionTitle
          title="Government Schemes"
          subtitle="Latest agricultural schemes and benefits for farmers"
        />

        <div className="mt-8 relative">
          <div className="relative">
            <input
              type="text"
              placeholder="Search schemes..."
              className="w-full px-4 py-3 pl-12 rounded-lg border border-gray-300 focus:ring-2 focus:ring-green-500 focus:border-transparent"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <Search className="absolute left-4 top-3.5 h-5 w-5 text-gray-400" />
          </div>
        </div>

        <div className="mt-8 space-y-6">
          {filteredSchemes.map((scheme, index) => (
            <div key={index} className="bg-gray-50 rounded-lg p-6 shadow-md hover:shadow-lg transition-shadow">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="text-xl font-semibold text-gray-900">{scheme.title}</h3>
                  <p className="mt-2 text-gray-600">{scheme.description}</p>
                  <p className="mt-2 text-sm text-gray-500">
                    <span className="font-medium">Eligibility:</span> {scheme.eligibility}
                  </p>
                </div>
                <a
                  href={scheme.link}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center text-green-600 hover:text-green-700"
                >
                  <span className="mr-1">Apply</span>
                  <ExternalLink className="h-4 w-4" />
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default GovernmentSchemes;