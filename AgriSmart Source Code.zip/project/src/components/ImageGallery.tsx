import React from 'react';
import SectionTitle from './ui/SectionTitle';

const ImageGallery = () => {
  const images = [
    {
      url: "https://images.unsplash.com/photo-1625246333195-78d9c38ad449",
      alt: "Smart Farming Technology",
      caption: "Modern Agricultural Technology"
    },
    {
      url: "https://images.unsplash.com/photo-1592982537447-6f2a6e0a3023",
      alt: "Sustainable Farming",
      caption: "Organic Farming Practices"
    },
    {
      url: "https://images.unsplash.com/photo-1530836369250-ef72a3f5cda8",
      alt: "Drone Technology in Agriculture",
      caption: "Precision Agriculture"
    },
    {
      url: "https://images.unsplash.com/photo-1615811361523-6bd03d7e0b06",
      alt: "Vertical Farming",
      caption: "Future of Agriculture"
    }
  ];

  return (
    <section className="py-12 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionTitle 
          title="Agricultural Innovation" 
          subtitle="Exploring modern farming techniques and sustainable practices" 
        />
        <div className="mt-10 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {images.map((image, index) => (
            <div key={index} className="relative overflow-hidden rounded-lg shadow-lg">
              <img
                src={`${image.url}?auto=format&fit=crop&w=800&q=80`}
                alt={image.alt}
                className="w-full h-48 object-cover transform hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4">
                <p className="text-white text-sm font-medium">{image.caption}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ImageGallery;