import React, { useState, useEffect } from 'react';
import { Cloud, Sun, CloudRain, Wind } from 'lucide-react';
import SectionTitle from '../ui/SectionTitle';

const WeatherWidget = () => {
  const [activeDay, setActiveDay] = useState(0);
  
  const weatherData = [
    { day: 'Today', temp: 28, humidity: 65, wind: 12, icon: <Sun className="h-8 w-8" /> },
    { day: 'Tomorrow', temp: 27, humidity: 70, wind: 10, icon: <Cloud className="h-8 w-8" /> },
    { day: 'Wed', temp: 25, humidity: 75, wind: 15, icon: <CloudRain className="h-8 w-8" /> },
    { day: 'Thu', temp: 26, humidity: 68, wind: 14, icon: <Wind className="h-8 w-8" /> },
  ];

  return (
    <section className="py-12 bg-white" id="weather">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionTitle 
          title="Weather Forecast" 
          subtitle="Plan your farming activities with accurate weather predictions" 
        />
        
        <div className="mt-10 grid grid-cols-1 md:grid-cols-4 gap-4">
          {weatherData.map((weather, index) => (
            <div
              key={index}
              className={`p-6 rounded-lg cursor-pointer transition-all duration-300 ${
                activeDay === index 
                  ? 'bg-green-600 text-white shadow-lg transform scale-105' 
                  : 'bg-gray-50 hover:bg-gray-100'
              }`}
              onClick={() => setActiveDay(index)}
            >
              <div className="flex items-center justify-between mb-4">
                <span className="font-semibold">{weather.day}</span>
                {weather.icon}
              </div>
              <div className="space-y-2">
                <p className="text-2xl font-bold">{weather.temp}°C</p>
                <p>Humidity: {weather.humidity}%</p>
                <p>Wind: {weather.wind} km/h</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default WeatherWidget;