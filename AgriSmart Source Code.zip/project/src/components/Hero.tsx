import React from 'react';
import { Sprout } from 'lucide-react';
import Button from './ui/Button';

const Hero = () => {
  return (
    <div className="relative">
      <div className="absolute inset-0">
        <img
          className="w-full h-full object-cover"
          src="https://images.unsplash.com/photo-1523741543316-beb7fc7023d8?auto=format&fit=crop&w=2000&q=80"
          alt="Modern Agriculture"
        />
        <div className="absolute inset-0 bg-green-700 mix-blend-multiply opacity-40" />
      </div>
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32">
        <div className="text-center">
          <Sprout className="h-16 w-16 mx-auto text-white" />
          <h1 className="mt-4 text-4xl font-bold tracking-tight text-white sm:text-5xl md:text-6xl">
            <span className="block">Smart Farming Solutions</span>
            <span className="block">for Better Tomorrow</span>
          </h1>
          <p className="mt-3 max-w-md mx-auto text-base text-gray-100 sm:text-lg md:mt-5 md:text-xl md:max-w-3xl">
            Get expert agricultural advice, real-time weather updates, and connect with the farming community.
          </p>
          <div className="mt-5 max-w-md mx-auto sm:flex sm:justify-center md:mt-8">
            <Button href="#advisory" variant="secondary">Get Started</Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;