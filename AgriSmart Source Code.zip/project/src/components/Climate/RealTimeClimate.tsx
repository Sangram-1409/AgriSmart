import React, { useState, useEffect } from 'react';
import { Thermometer, Droplets, Wind, Sun, CloudRain } from 'lucide-react';
import SectionTitle from '../ui/SectionTitle';

const RealTimeClimate = () => {
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const climateData = {
    temperature: 28.5,
    humidity: 65,
    windSpeed: 12,
    rainfall: 0.2,
    uvIndex: 6,
    soilMoisture: 42
  };

  const ClimateCard = ({ icon, title, value, unit }: any) => (
    <div className="bg-white p-6 rounded-lg shadow-lg">
      <div className="flex items-center justify-between mb-4">
        <span className="text-green-600">{icon}</span>
        <span className="text-sm text-gray-500">{currentTime.toLocaleTimeString()}</span>
      </div>
      <h3 className="text-lg font-medium text-gray-900">{title}</h3>
      <p className="mt-2 text-3xl font-bold text-green-600">
        {value}
        <span className="text-base font-normal text-gray-500 ml-1">{unit}</span>
      </p>
    </div>
  );

  return (
    <section className="py-12 bg-gray-50" id="climate">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionTitle
          title="Real-Time Climate Conditions"
          subtitle="Live agricultural weather metrics for informed decision making"
        />
        
        <div className="mt-10 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <ClimateCard
            icon={<Thermometer className="h-6 w-6" />}
            title="Temperature"
            value={climateData.temperature}
            unit="°C"
          />
          <ClimateCard
            icon={<Droplets className="h-6 w-6" />}
            title="Humidity"
            value={climateData.humidity}
            unit="%"
          />
          <ClimateCard
            icon={<Wind className="h-6 w-6" />}
            title="Wind Speed"
            value={climateData.windSpeed}
            unit="km/h"
          />
          <ClimateCard
            icon={<CloudRain className="h-6 w-6" />}
            title="Rainfall"
            value={climateData.rainfall}
            unit="mm"
          />
          <ClimateCard
            icon={<Sun className="h-6 w-6" />}
            title="UV Index"
            value={climateData.uvIndex}
            unit="/10"
          />
          <ClimateCard
            icon={<Droplets className="h-6 w-6" />}
            title="Soil Moisture"
            value={climateData.soilMoisture}
            unit="%"
          />
        </div>
      </div>
    </section>
  );
};

export default RealTimeClimate;