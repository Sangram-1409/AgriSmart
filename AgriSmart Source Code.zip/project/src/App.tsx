import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Features from './components/Features';
import RealTimeClimate from './components/Climate/RealTimeClimate';
import CropRecommendation from './components/CropAdvisory/CropRecommendation';
import WeatherWidget from './components/Weather/WeatherWidget';
import MarketplaceSection from './components/Marketplace/MarketplaceSection';
import GovernmentSchemes from './components/Schemes/GovernmentSchemes';
import ImageGallery from './components/ImageGallery';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow">
        <Hero />
        <Features />
        <RealTimeClimate />
        <CropRecommendation />
        <WeatherWidget />
        <GovernmentSchemes />
        <MarketplaceSection />
        <ImageGallery />
      </main>
      <Footer />
    </div>
  );
}

export default App;